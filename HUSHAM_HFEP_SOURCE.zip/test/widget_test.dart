import 'package:flutter_test/flutter_test.dart';
import 'package:hfep_mobile/main.dart';

void main() {
  testWidgets('HFEP home screen renders Arabic identity and core services',
      (tester) async {
    await tester.pumpWidget(const HfepApp());

    expect(find.text('منصة هشام الفراتي التعليمية'), findsOneWidget);
    expect(find.text('الخدمات التعليمية'), findsOneWidget);
    expect(find.text('المكتبة العلمية'), findsOneWidget);
    expect(find.text('الاختبارات'), findsOneWidget);
    expect(find.text('مدرستي'), findsOneWidget);
  });
}
