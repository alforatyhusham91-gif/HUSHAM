import 'package:flutter/material.dart';

class AppShell extends StatelessWidget {
  const AppShell({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('منصة هشام الفراتي التعليمية',
            style: TextStyle(fontWeight: FontWeight.w800)),
        actions: [
          IconButton(
            tooltip: 'الإشعارات',
            onPressed: () {},
            icon: const Icon(Icons.notifications_none_rounded),
          ),
        ],
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Container(
            padding: const EdgeInsets.all(20),
            decoration: BoxDecoration(
              gradient: const LinearGradient(
                colors: [Color(0xFF092B50), Color(0xFF14558A)],
                begin: Alignment.topRight,
                end: Alignment.bottomLeft,
              ),
              borderRadius: BorderRadius.circular(22),
            ),
            child: const Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('مرحبًا بك في منصتك التعليمية',
                    style: TextStyle(color: Colors.white, fontSize: 20,
                        fontWeight: FontWeight.bold)),
                SizedBox(height: 8),
                Text('تعلم، اختبر، وتابع تقدمك في مكان واحد.',
                    style: TextStyle(color: Colors.white70, fontSize: 14)),
              ],
            ),
          ),
          const SizedBox(height: 20),
          const Text('الخدمات التعليمية',
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
          const SizedBox(height: 10),
          const _FeatureTile(icon: Icons.menu_book_rounded,
              title: 'المكتبة العلمية', subtitle: 'الدروس والكتب والملازم'),
          const _FeatureTile(icon: Icons.quiz_rounded,
              title: 'الاختبارات', subtitle: 'اختبر معلوماتك وتابع نتائجك'),
          const _FeatureTile(icon: Icons.account_balance_rounded,
              title: 'مدرستي', subtitle: 'الصفوف والمواد والإعلانات'),
          const _FeatureTile(icon: Icons.insights_rounded,
              title: 'مستوى التقدم', subtitle: 'متابعة الإنجاز والتحصيل'),
          const SizedBox(height: 16),
          const Text(
            'نسخة تأسيسية تجريبية — الخدمات ستُفعّل تدريجيًا بعد ربط قاعدة البيانات.',
            textAlign: TextAlign.center,
            style: TextStyle(color: Colors.black54, fontSize: 12),
          ),
        ],
      ),
      bottomNavigationBar: NavigationBar(
        selectedIndex: 0,
        destinations: const [
          NavigationDestination(icon: Icon(Icons.home_outlined), label: 'الرئيسية'),
          NavigationDestination(icon: Icon(Icons.library_books_outlined), label: 'المكتبة'),
          NavigationDestination(icon: Icon(Icons.school_outlined), label: 'مدرستي'),
          NavigationDestination(icon: Icon(Icons.person_outline), label: 'حسابي'),
        ],
      ),
    );
  }
}

class _FeatureTile extends StatelessWidget {
  const _FeatureTile({required this.icon, required this.title, required this.subtitle});
  final IconData icon;
  final String title;
  final String subtitle;

  @override
  Widget build(BuildContext context) {
    return Card(
      margin: const EdgeInsets.only(bottom: 9),
      child: ListTile(
        leading: CircleAvatar(
          backgroundColor: const Color(0xFFE7EFF7),
          foregroundColor: const Color(0xFF092B50),
          child: Icon(icon),
        ),
        title: Text(title, style: const TextStyle(fontWeight: FontWeight.bold)),
        subtitle: Text(subtitle),
        trailing: const Icon(Icons.chevron_left_rounded),
        onTap: () {},
      ),
    );
  }
}
