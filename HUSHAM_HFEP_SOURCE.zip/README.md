# منصة هشام الفراتي التعليمية — HFEP

Flutter Android-first starter for a multi-school educational platform.

## Contents
- Arabic RTL Flutter shell.
- Supabase multi-tenant foundation and RLS migration.
- Tenant-integrity/profile bootstrap hardening migration.
- Android-only setup guide for Supabase + GitHub Codespaces.
- GitHub Actions workflow for analysis, widget tests, and debug APK artifact.
- Database acceptance test matrix.

## Quick start
Read `docs/ANDROID_ONLY_SETUP_AR.md` first. Apply migrations in numeric order to a new Supabase project. Never place a Supabase `service_role` key in the mobile app or CI build variables.

## Status
Starter scaffold only. Not yet connected to a live Supabase project, not yet acceptance-tested against real Auth users, and not a production release.
