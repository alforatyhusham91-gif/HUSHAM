# دليل التشغيل من هاتف Android فقط

## 1) إنشاء مشروع Supabase

1. افتح https://supabase.com/dashboard من Chrome وسجّل الدخول أو أنشئ حسابًا.
2. اختر إنشاء Organization إذا لم تكن لديك واحدة، ثم New project.
3. الاسم المقترح: `hfep-production` للمشروع النهائي أو `hfep-pilot` للتجربة. ابدأ باسم `hfep-pilot`.
4. اختر كلمة مرور قوية لقاعدة البيانات واحفظها في مدير كلمات مرورك؛ لا ترسلها في المحادثة.
5. اختر أقرب منطقة متاحة مناسبة، ثم أنشئ المشروع وانتظر اكتمال التجهيز.
6. من Project Settings ثم API انسخ Project URL و`anon`/Publishable key فقط. لا تنسخ `service_role` أو Secret key.
7. افتح SQL Editor، ثم شغّل محتوى الملف `supabase/migrations/0001_multi_school_foundation.sql` كاملًا. بعد نجاحه شغّل `0002_integrity_and_profile_bootstrap.sql`.

## 2) إنشاء أول حساب إداري

1. من Authentication > Users أنشئ مستخدمًا تجريبيًا ببريد تملكه.
2. انسخ UUID الخاص بالمستخدم من قائمة المستخدمين.
3. في SQL Editor نفّذ الأمر التالي بعد استبدال القيمتين. لا تضع البريد بدل UUID.

```sql
insert into public.organizations (name, slug, organization_type)
values ('منصة هشام الفراتي التجريبية', 'hfep-pilot', 'academy')
returning id;
```

4. انسخ `id` الناتج ثم نفّذ:

```sql
insert into public.memberships (organization_id, user_id, role)
values ('PUT_ORGANIZATION_UUID_HERE', 'PUT_AUTH_USER_UUID_HERE', 'platform_owner');
```

5. تحقق من إنشاء profile:

```sql
select id, full_name, created_at from public.profiles
where id = 'PUT_AUTH_USER_UUID_HERE';
```

## 3) تجهيز مستودع GitHub

1. افتح https://github.com من Chrome وأنشئ مستودعًا خاصًا باسم `hfep-mobile`.
2. ارفع ملف `hfep_mvp_starter.zip` نفسه إلى المستودع من Add file > Upload files ثم Commit changes.
3. افتح المستودع ثم Code > Codespaces > Create codespace on main.
4. انتظر تجهيز بيئة Linux السحابية، وافتح Terminal من واجهة VS Code في المتصفح.
5. فك الحزمة وانقل محتوياتها إلى جذر المستودع (مهم حتى يظهر مجلد `.github` في الجذر):

```bash
unzip hfep_mvp_starter.zip
cp -a hfep_mvp/. .
rm -rf hfep_mvp hfep_mvp_starter.zip
git add .
git commit -m "Add HFEP Flutter starter"
git push origin main
```

6. نفّذ:

```bash
flutter --version
flutter pub get
flutter analyze
flutter test
```

## 4) ضبط متغيرات GitHub Actions

في المستودع: Settings > Secrets and variables > Actions > Variables > New repository variable.

أضف:
- `SUPABASE_URL` = Project URL.
- `SUPABASE_ANON_KEY` = anon/publishable key.

هذه مفاتيح عميل عامة وليست مفاتيح سرية بصلاحية الإدارة؛ تظل سياسات RLS إلزامية. لا تضف `service_role` مطلقًا.

## 5) بناء APK

1. احفظ التغييرات وارفعها إلى فرع `main` (Commit ثم Push).
2. افتح تبويب Actions في GitHub.
3. افتح تشغيل `HFEP Flutter CI and Android APK` وانتظر نجاح التحليل والاختبارات والبناء.
4. من Artifacts نزّل `hfep-android-debug-apk` إلى الهاتف.
5. ثبّت APK للاختبار التجريبي فقط. قد يطلب Android السماح بالتثبيت من Chrome/مدير الملفات.

## 6) تشغيل قبول أولي

- افتح التطبيق وتأكد من ظهور الهوية العربية والخدمات الرئيسية.
- اختبر إنشاء حساب، تسجيل الدخول، الخروج، ثم إغلاق التطبيق وفتحه للتحقق من الجلسة.
- اختبر قراءة المحتوى بحساب طالب، وإدارة المحتوى بحساب معلم، وإدارة المؤسسة بحساب مدير.
- نفّذ جدول الاختبارات في `supabase/tests/ACCEPTANCE_TESTS_AR.md` بحسابات منفصلة للمؤسستين.

## حدود النسخة الحالية

- الحزمة الحالية نقطة انطلاق MVP وليست منصة إنتاجية مكتملة.
- لا تزال شاشات الدخول، إدارة المستخدمين، الملفات، الاختبارات، الإشعارات، ولوحة الإدارة بحاجة إلى تنفيذ مستقل.
- ملف APK الذي تنتجه هذه المرحلة Debug للتجربة، وليس إصدارًا موقعًا للنشر العام.
- يلزم اختبار RLS عمليًا قبل إدخال بيانات طلاب حقيقية.
