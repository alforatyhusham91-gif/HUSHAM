-- HFEP: multi-school foundation. Apply in a new Supabase project.
-- All tenant-owned records carry organization_id and are protected by RLS.

create extension if not exists pgcrypto;

create type public.member_role as enum (
  'platform_owner', 'school_admin', 'teacher', 'student', 'parent'
);

create table public.organizations (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  slug text not null unique,
  organization_type text not null default 'school'
    check (organization_type in ('school','institute','academy')),
  is_active boolean not null default true,
  created_at timestamptz not null default now()
);

create table public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  full_name text not null default '',
  phone text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table public.memberships (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null references public.organizations(id) on delete cascade,
  user_id uuid not null references auth.users(id) on delete cascade,
  role public.member_role not null,
  is_active boolean not null default true,
  created_at timestamptz not null default now(),
  unique (organization_id, user_id)
);

create table public.academic_years (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null references public.organizations(id) on delete cascade,
  name text not null,
  starts_on date,
  ends_on date,
  is_current boolean not null default false,
  created_at timestamptz not null default now(),
  unique (organization_id, name)
);

create table public.classrooms (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null references public.organizations(id) on delete cascade,
  academic_year_id uuid references public.academic_years(id) on delete set null,
  name text not null,
  grade_level text,
  created_at timestamptz not null default now()
);

create table public.subjects (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null references public.organizations(id) on delete cascade,
  name text not null,
  grade_level text,
  description text,
  created_at timestamptz not null default now()
);

create table public.lessons (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null references public.organizations(id) on delete cascade,
  subject_id uuid not null references public.subjects(id) on delete cascade,
  title text not null,
  summary text,
  body_markdown text,
  sort_order integer not null default 0,
  is_published boolean not null default false,
  created_by uuid references auth.users(id) on delete set null,
  created_at timestamptz not null default now()
);

create table public.enrollments (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null references public.organizations(id) on delete cascade,
  classroom_id uuid not null references public.classrooms(id) on delete cascade,
  student_id uuid not null references auth.users(id) on delete cascade,
  created_at timestamptz not null default now(),
  unique (classroom_id, student_id)
);

create index memberships_user_org_idx on public.memberships(user_id, organization_id);
create index lessons_org_subject_idx on public.lessons(organization_id, subject_id, sort_order);
create index enrollments_student_idx on public.enrollments(student_id);

create or replace function public.is_org_member(target_org uuid)
returns boolean
language sql stable security definer
set search_path = ''
as $$
  select exists (
    select 1 from public.memberships m
    where m.organization_id = target_org
      and m.user_id = (select auth.uid())
      and m.is_active = true
  );
$$;

create or replace function public.has_org_role(target_org uuid, allowed_roles public.member_role[])
returns boolean
language sql stable security definer
set search_path = ''
as $$
  select exists (
    select 1 from public.memberships m
    where m.organization_id = target_org
      and m.user_id = (select auth.uid())
      and m.is_active = true
      and m.role = any(allowed_roles)
  );
$$;

alter table public.organizations enable row level security;
alter table public.profiles enable row level security;
alter table public.memberships enable row level security;
alter table public.academic_years enable row level security;
alter table public.classrooms enable row level security;
alter table public.subjects enable row level security;
alter table public.lessons enable row level security;
alter table public.enrollments enable row level security;

create policy "members can read their organizations"
on public.organizations for select to authenticated
using (public.is_org_member(id));

create policy "users can read own profile"
on public.profiles for select to authenticated
using (id = (select auth.uid()));
create policy "users can update own profile"
on public.profiles for update to authenticated
using (id = (select auth.uid()))
with check (id = (select auth.uid()));

create policy "members can read memberships in their organization"
on public.memberships for select to authenticated
using (public.is_org_member(organization_id));

create policy "members can read academic years"
on public.academic_years for select to authenticated
using (public.is_org_member(organization_id));
create policy "school admins manage academic years"
on public.academic_years for all to authenticated
using (public.has_org_role(organization_id, array['platform_owner','school_admin']::public.member_role[]))
with check (public.has_org_role(organization_id, array['platform_owner','school_admin']::public.member_role[]));

create policy "members can read classrooms"
on public.classrooms for select to authenticated
using (public.is_org_member(organization_id));
create policy "school admins manage classrooms"
on public.classrooms for all to authenticated
using (public.has_org_role(organization_id, array['platform_owner','school_admin']::public.member_role[]))
with check (public.has_org_role(organization_id, array['platform_owner','school_admin']::public.member_role[]));

create policy "members can read subjects"
on public.subjects for select to authenticated
using (public.is_org_member(organization_id));
create policy "admins and teachers manage subjects"
on public.subjects for all to authenticated
using (public.has_org_role(organization_id, array['platform_owner','school_admin','teacher']::public.member_role[]))
with check (public.has_org_role(organization_id, array['platform_owner','school_admin','teacher']::public.member_role[]));

create policy "members can read published lessons"
on public.lessons for select to authenticated
using (
  public.is_org_member(organization_id)
  and (is_published or public.has_org_role(organization_id, array['platform_owner','school_admin','teacher']::public.member_role[]))
);
create policy "admins and teachers manage lessons"
on public.lessons for all to authenticated
using (public.has_org_role(organization_id, array['platform_owner','school_admin','teacher']::public.member_role[]))
with check (public.has_org_role(organization_id, array['platform_owner','school_admin','teacher']::public.member_role[]));

create policy "students and staff read enrollments"
on public.enrollments for select to authenticated
using (
  public.has_org_role(organization_id, array['platform_owner','school_admin','teacher']::public.member_role[])
  or student_id = (select auth.uid())
);
create policy "school admins manage enrollments"
on public.enrollments for all to authenticated
using (public.has_org_role(organization_id, array['platform_owner','school_admin']::public.member_role[]))
with check (public.has_org_role(organization_id, array['platform_owner','school_admin']::public.member_role[]));

-- Intentionally no public INSERT policy for organizations or memberships.
-- Provision the first platform owner and create schools through a trusted
-- server-side/admin workflow; never expose the service_role key in the app.

revoke all on public.organizations, public.profiles, public.memberships,
  public.academic_years, public.classrooms, public.subjects,
  public.lessons, public.enrollments from anon;

grant select on public.organizations, public.memberships, public.academic_years,
  public.classrooms, public.subjects, public.lessons, public.enrollments to authenticated;
grant select, update on public.profiles to authenticated;
grant insert, update, delete on public.academic_years, public.classrooms,
  public.subjects, public.lessons to authenticated;
grant insert, update, delete on public.enrollments to authenticated;
