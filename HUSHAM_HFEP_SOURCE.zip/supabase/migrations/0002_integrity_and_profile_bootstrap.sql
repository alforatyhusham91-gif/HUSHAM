-- HFEP hardening migration. Apply after 0001 on a fresh project.
-- Enforces tenant-consistent foreign keys and creates a profile for each new auth user.

-- Composite unique keys are required as FK targets for tenant-consistency checks.
alter table public.academic_years
  add constraint academic_years_id_org_unique unique (id, organization_id);
alter table public.classrooms
  add constraint classrooms_id_org_unique unique (id, organization_id);
alter table public.subjects
  add constraint subjects_id_org_unique unique (id, organization_id);

-- A classroom cannot point to an academic year belonging to another organization.
alter table public.classrooms
  add constraint classrooms_academic_year_same_org_fk
  foreign key (academic_year_id, organization_id)
  references public.academic_years (id, organization_id)
  on delete set null (academic_year_id);

-- A lesson cannot point to a subject belonging to another organization.
alter table public.lessons
  drop constraint lessons_subject_id_fkey;
alter table public.lessons
  add constraint lessons_subject_same_org_fk
  foreign key (subject_id, organization_id)
  references public.subjects (id, organization_id)
  on delete cascade;

-- An enrollment cannot point to a classroom belonging to another organization.
alter table public.enrollments
  add constraint enrollments_classroom_same_org_fk
  foreign key (classroom_id, organization_id)
  references public.classrooms (id, organization_id)
  on delete cascade;

-- Students must be active members of the same organization to read their enrollment.
drop policy if exists "students and staff read enrollments" on public.enrollments;
create policy "members read permitted enrollments"
on public.enrollments for select to authenticated
using (
  public.is_org_member(organization_id)
  and (
    public.has_org_role(organization_id, array['platform_owner','school_admin','teacher']::public.member_role[])
    or student_id = (select auth.uid())
  )
);

-- Automatically create a minimal profile after Supabase Auth creates a user.
create or replace function public.handle_new_auth_user()
returns trigger
language plpgsql
security definer
set search_path = ''
as $$
begin
  insert into public.profiles (id, full_name)
  values (
    new.id,
    coalesce(new.raw_user_meta_data ->> 'full_name', '')
  )
  on conflict (id) do nothing;
  return new;
end;
$$;

drop trigger if exists on_auth_user_created_profile on auth.users;
create trigger on_auth_user_created_profile
after insert on auth.users
for each row execute procedure public.handle_new_auth_user();

-- Keep updated_at current when a user edits their profile.
create or replace function public.set_updated_at()
returns trigger
language plpgsql
set search_path = ''
as $$
begin
  new.updated_at = now();
  return new;
end;
$$;

drop trigger if exists profiles_set_updated_at on public.profiles;
create trigger profiles_set_updated_at
before update on public.profiles
for each row execute procedure public.set_updated_at();

create index if not exists classrooms_org_year_idx
  on public.classrooms (organization_id, academic_year_id);
create index if not exists subjects_org_name_idx
  on public.subjects (organization_id, name);
create index if not exists enrollments_org_classroom_idx
  on public.enrollments (organization_id, classroom_id);
